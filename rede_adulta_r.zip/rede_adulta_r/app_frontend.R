# app_frontend.R
library(shiny)
library(bslib)
library(DBI)
library(RSQLite)
library(sodium)
library(httr)

if (!dir.exists("www")) dir.create("www")
addResourcePath("media", "www")

get_db <- function() {
  dbConnect(RSQLite::SQLite(), "plataforma_adulta.sqlite")
}

ui <- page_fluid(
  theme = bs_theme(
    version = 5,
    bg = "#0d0d12",
    fg = "#f1f1f1",
    primary = "#e11d48",
    secondary = "#27273a",
    base_font = font_google("Inter")
  ),
  tags$head(
    tags$style(HTML("
      .card-custom { background-color: #161622; border: 1px solid #2a2a3d; border-radius: 12px; padding: 20px; margin-bottom: 20px; }
      .live-badge { background: #e11d48; color: white; padding: 3px 10px; border-radius: 20px; font-weight: bold; font-size: 12px; animation: pulse 1.5s infinite; }
      @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }
      .video-wrapper { position: relative; width: 100%; background: #000; border-radius: 10px; overflow: hidden; }
      .watermark { position: absolute; top: 15px; right: 20px; color: rgba(255,255,255,0.45); font-size: 13px; pointer-events: none; z-index: 10; font-family: monospace; }
      .paywall-box { background: linear-gradient(135deg, #1f1221 0%, #14141f 100%); border: 2px solid #e11d48; padding: 40px; text-align: center; border-radius: 12px; }
    "))
  ),
  uiOutput("main_screen")
)

server <- function(input, output, session) {
  # Estados reativos da sessão
  age_verified <- reactiveVal(FALSE)
  current_user <- reactiveVal(NULL)
  refresh_trigger <- reactiveVal(0)
  selected_live_id <- reactiveVal(NULL)
  
  # 1. TELA DE BLOQUEIO +18 (AGE GATE)
  output$main_screen <- renderUI({
    if (!age_verified()) {
      return(
        div(class = "container d-flex justify-content-center align-items-center", style = "height: 100vh;",
            div(class = "card-custom text-center", style = "max-width: 480px;",
                h2("Conteúdo Adulto (+18)", style = "color: #e11d48; font-weight: 800;"),
                p("Esta plataforma contém material destinado exclusivamente a adultos maiores de 18 anos."),
                p("Ao continuar, você declara ter idade legal em sua jurisdição."),
                br(),
                actionButton("confirm_age", "Tenho 18 anos ou mais - Entrar", class = "btn-primary btn-lg w-100")
            )
        )
      )
    }
    
    # 2. TELA DE LOGIN / CADASTRO
    if (is.null(current_user())) {
      return(
        div(class = "container", style = "max-width: 450px; margin-top: 60px;",
            div(class = "card-custom",
                h3("Acesso à Plataforma", class = "text-center mb-4"),
                tabsetPanel(
                  tabPanel("Entrar",
                           br(),
                           textInput("login_email", "E-mail", placeholder = "admin@plataforma.com"),
                           passwordInput("login_pass", "Senha", placeholder = "admin123"),
                           actionButton("btn_login", "Entrar", class = "btn-primary w-100")
                  ),
                  tabPanel("Criar Conta",
                           br(),
                           textInput("reg_user", "Nome de Usuário (@)"),
                           textInput("reg_email", "E-mail"),
                           passwordInput("reg_pass", "Senha"),
                           checkboxInput("reg_age", "Confirmo que tenho +18 anos", value = TRUE),
                           actionButton("btn_register", "Cadastrar", class = "btn-success w-100")
                  )
                )
            )
        )
      )
    }
    
    # 3. PLATAFORMA LOGADA (USUÁRIO OU ADMIN)
    user <- current_user()
    
    nav_items <- list(
      # ABA 1: TIMELINE
      nav_panel("Timeline",
                div(class = "row mt-4",
                    div(class = "col-md-8 mx-auto",
                        # Caixa de Nova Postagem
                        div(class = "card-custom",
                            h5("Criar Publicação"),
                            textAreaInput("post_text", NULL, placeholder = "Compartilhe algo com seus seguidores...", width = "100%", rows = 2),
                            fileInput("post_media", "Anexar Foto ou Vídeo (MP4/JPG/PNG)", accept = c("image/png", "image/jpeg", "video/mp4")),
                            actionButton("btn_publish", "Publicar na Timeline", class = "btn-primary")
                        ),
                        uiOutput("timeline_feed")
                    )
                )
      ),
      
      # ABA 2: LIVES AO VIVO (PAY-PER-VIEW)
      nav_panel("Lives ao Vivo",
                div(class = "row mt-4",
                    div(class = "col-md-4",
                        div(class = "card-custom",
                            h5("Iniciar Transmissão Paga"),
                            textInput("live_title", "Título da Live"),
                            textAreaInput("live_desc", "Descrição / O que vai rolar"),
                            numericInput("live_price", "Valor do Ingresso (R$)", value = 25.00, min = 5, max = 500),
                            textInput("live_url", "URL do Stream (HLS .m3u8)", value = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
                            actionButton("btn_start_live", "Iniciar Live Agora", class = "btn-danger w-100")
                        )
                    ),
                    div(class = "col-md-8",
                        uiOutput("live_player_area"),
                        h5("Transmissões Ativas no Momento", class = "mt-3"),
                        uiOutput("active_lives_list")
                    )
                )
      ),
      
      # ABA 3: MEU PERFIL & CARTEIRA
      nav_panel("Meu Perfil",
                div(class = "row mt-4",
                    div(class = "col-md-6 mx-auto",
                        div(class = "card-custom",
                            h4(paste0("@", user$username)),
                            span(class = "badge bg-info", toupper(user$role)),
                            hr(),
                            h5(paste0("Saldo em Carteira: R$ ", sprintf("%.2f", user$wallet_balance))),
                            actionButton("btn_add_funds", "+ Adicionar R$ 50,00 (Simular Pix)", class = "btn-outline-success btn-sm mb-3"),
                            hr(),
                            h5("Editar Informações do Perfil"),
                            textAreaInput("edit_bio", "Biografia", value = user$bio),
                            fileInput("edit_avatar", "Alterar Foto de Perfil", accept = c("image/png", "image/jpeg")),
                            actionButton("btn_save_profile", "Salvar Alterações", class = "btn-primary")
                        )
                    )
                )
      )
    )
    
    # ABA 4: PAINEL ADMINISTRADOR (Visível apenas para role == 'admin')
    if (user$role == "admin") {
      nav_items[[length(nav_items) + 1]] <- nav_panel(
        "Painel Admin",
        div(class = "container mt-4",
            h3("Administração Geral & Financeiro"),
            uiOutput("admin_stats"),
            div(class = "card-custom mt-3",
                h5("Gerenciar Usuários e Verificação KYC (+18)"),
                tableOutput("admin_users_table"),
                numericInput("verify_user_id", "ID do Usuário para Aprovar KYC:", value = 2, min = 1),
                actionButton("btn_verify_user", "Aprovar Selo +18", class = "btn-success")
            ),
            div(class = "card-custom mt-3",
                h5("Moderação de Postagens"),
                numericInput("del_post_id", "ID do Post para Remover:", value = 1, min = 1),
                actionButton("btn_del_post", "Excluir Postagem", class = "btn-danger")
            )
        )
      )
    }
    
    page_navbar(
      title = "VIP CLUB +18",
      bg = "#161622",
      !!!nav_items,
      nav_spacer(),
      nav_item(span(paste0("R$ ", sprintf("%.2f", user$wallet_balance)), class = "badge bg-success me-3 mt-2")),
      nav_item(actionButton("btn_logout", "Sair", class = "btn-outline-light btn-sm"))
    )
  })
  
  # --- EVENTOS DE AUTENTICAÇÃO ---
  observeEvent(input$confirm_age, { age_verified(TRUE) })
  
  observeEvent(input$btn_login, {
    con <- get_db()
    on.exit(dbDisconnect(con))
    user <- dbGetQuery(con, "SELECT * FROM users WHERE email = ?", params = list(input$login_email))
    if (nrow(user) > 0 && sodium::password_verify(user$password_hash[1], input$login_pass)) {
      current_user(as.list(user[1, ]))
    } else {
      showNotification("E-mail ou senha incorretos.", type = "error")
    }
  })
  
  observeEvent(input$btn_register, {
    res <- POST("http://127.0.0.1:8000/auth/register", body = list(
      username = input$reg_user, email = input$reg_email,
      password = input$reg_pass, age_confirmed = input$reg_age
    ), encode = "form")
    data <- content(res)
    showNotification(data$message, type = ifelse(data$status == "success", "message", "error"))
  })
  
  observeEvent(input$btn_logout, { current_user(NULL); selected_live_id(NULL) })
  
  # --- EVENTOS DA TIMELINE ---
  observeEvent(input$btn_publish, {
    user <- current_user()
    media_file <- ""
    media_type <- "text"
    
    if (!is.null(input$post_media)) {
      ext <- tools::file_ext(input$post_media$name)
      new_name <- paste0("post_", as.integer(Sys.time()), ".", ext)
      file.copy(input$post_media$datapath, file.path("www", new_name))
      media_file <- new_name
      media_type <- ifelse(tolower(ext) == "mp4", "video", "image")
    }
    
    con <- get_db()
    dbExecute(con, "INSERT INTO posts (user_id, content_text, media_path, media_type) VALUES (?, ?, ?, ?)",
              params = list(user$id, input$post_text, media_file, media_type))
    dbDisconnect(con)
    
    updateTextAreaInput(session, "post_text", value = "")
    refresh_trigger(refresh_trigger() + 1)
    showNotification("Publicado na timeline!", type = "message")
  })
  
  output$timeline_feed <- renderUI({
    refresh_trigger()
    con <- get_db()
    on.exit(dbDisconnect(con))
    posts <- dbGetQuery(con, "
      SELECT p.*, u.username, u.is_verified 
      FROM posts p JOIN users u ON p.user_id = u.id 
      ORDER BY p.created_at DESC
    ")
    
    if (nrow(posts) == 0) return(p("Nenhuma publicação ainda. Seja o primeiro a postar!", class = "text-muted"))
    
    lapply(seq_len(nrow(posts)), function(i) {
      p_row <- posts[i, ]
      badge_verif <- if (p_row$is_verified == 1) span(" ✓ Verificado", class = "badge bg-primary ms-1") else NULL
      
      media_ui <- NULL
      if (p_row$media_type == "image" && p_row$media_path != "") {
        media_ui <- tags$img(src = paste0("media/", p_row$media_path), style = "width:100%; border-radius:8px; margin-top:10px;")
      } else if (p_row$media_type == "video" && p_row$media_path != "") {
        media_ui <- tags$video(src = paste0("media/", p_row$media_path), controls = TRUE, style = "width:100%; border-radius:8px; margin-top:10px;")
      }
      
      div(class = "card-custom",
          div(class = "d-flex justify-content-between",
              strong(paste0("@", p_row$username), badge_verif),
              small(class = "text-muted", paste0("ID #", p_row$id, " • ", p_row$created_at))
          ),
          p(class = "mt-2", p_row$content_text),
          media_ui
      )
    })
  })
  
  # --- EVENTOS DE LIVE AO VIVO PAGA ---
  observeEvent(input$btn_start_live, {
    user <- current_user()
    con <- get_db()
    stream_key <- paste0("live_", user$id, "_", as.integer(Sys.time()))
    dbExecute(con, "
      INSERT INTO live_streams (creator_id, title, description, ticket_price, stream_key, hls_url)
      VALUES (?, ?, ?, ?, ?, ?)
    ", params = list(user$id, input$live_title, input$live_desc, input$live_price, stream_key, input$live_url))
    dbDisconnect(con)
    refresh_trigger(refresh_trigger() + 1)
    showNotification("Sua live paga está no ar!", type = "message")
  })
  
  output$active_lives_list <- renderUI({
    refresh_trigger()
    con <- get_db()
    on.exit(dbDisconnect(con))
    lives <- dbGetQuery(con, "
      SELECT l.*, u.username FROM live_streams l 
      JOIN users u ON l.creator_id = u.id WHERE l.status = 'live' ORDER BY l.id DESC
    ")
    
    if (nrow(lives) == 0) return(p("Nenhuma live ativa no momento.", class = "text-muted"))
    
    lapply(seq_len(nrow(lives)), function(i) {
      lv <- lives[i, ]
      div(class = "card-custom d-flex justify-content-between align-items-center",
          div(
            span("AO VIVO", class = "live-badge me-2"),
            strong(lv$title),
            p(class = "mb-0 text-muted", paste0("Por @", lv$username, " • ", lv$description))
          ),
          actionButton(paste0("watch_live_", lv$id), paste0("Assistir (R$ ", sprintf("%.2f", lv$ticket_price), ")"),
                       class = "btn-primary",
                       onclick = sprintf("Shiny.setInputValue('select_live', %d, {priority: 'event'})", lv$id))
      )
    })
  })
  
  observeEvent(input$select_live, { selected_live_id(input$select_live) })
  
  output$live_player_area <- renderUI({
    refresh_trigger()
    lid <- selected_live_id()
    if (is.null(lid)) return(NULL)
    
    user <- current_user()
    res <- GET("http://127.0.0.1:8000/lives/stream_access", query = list(user_id = user$id, live_id = lid))
    access <- content(res)
    
    con <- get_db()
    live <- dbGetQuery(con, "SELECT * FROM live_streams WHERE id = ?", params = list(lid))
    dbDisconnect(con)
    
    if (isTRUE(access$authorized)) {
      # PLAYER LIBERADO COM MARCA D'ÁGUA DINÂMICA ANTI-PIRATARIA
      div(class = "card-custom",
          div(class = "d-flex justify-content-between mb-2",
              h4(live$title[1]),
              span("ACESSO LIBERADO", class = "badge bg-success")
          ),
          div(class = "video-wrapper",
              div(class = "watermark", paste0("ID:", user$id, " | @", user$username, " | IP PROTEGIDO")),
              tags$video(id = "liveVideoPlayer", controls = TRUE, autoplay = TRUE, style = "width:100%; max-height: 450px;",
                         tags$source(src = access$hls_url, type = "application/x-mpegURL"))
          ),
          tags$script(HTML(sprintf("
            var video = document.getElementById('liveVideoPlayer');
            if (video.canPlayType('application/vnd.apple.mpegurl')) {
              video.src = '%s';
            }
          ", access$hls_url)))
      )
    } else {
      # TELA DE BLOQUEIO (PAYWALL) EXIGINDO PAGAMENTO
      div(class = "paywall-box mb-4",
          h3("Transmissão Exclusiva Paga"),
          p(paste0("Para assistir à live '", live$title[1], "', adquira o ingresso abaixo.")),
          h2(paste0("R$ ", sprintf("%.2f", live$ticket_price[1])), style = "color: #e11d48; font-weight: bold;"),
          actionButton("btn_pay_ticket", "Pagar com Saldo e Liberar Agora", class = "btn-primary btn-lg mt-2")
      )
    }
  })
  
  observeEvent(input$btn_pay_ticket, {
    user <- current_user()
    lid <- selected_live_id()
    res <- POST("http://127.0.0.1:8000/lives/buy_ticket", body = list(buyer_id = user$id, live_id = lid), encode = "form")
    data <- content(res)
    
    if (data$status == "success") {
      con <- get_db()
      updated <- dbGetQuery(con, "SELECT * FROM users WHERE id = ?", params = list(user$id))
      dbDisconnect(con)
      current_user(as.list(updated[1, ]))
      refresh_trigger(refresh_trigger() + 1)
      showNotification(data$message, type = "message")
    } else {
      showNotification(data$message, type = "error")
    }
  })
  
  # --- PERFIL & ADMIN ---
  observeEvent(input$btn_add_funds, {
    user <- current_user()
    con <- get_db()
    dbExecute(con, "UPDATE users SET wallet_balance = wallet_balance + 50 WHERE id = ?", params = list(user$id))
    updated <- dbGetQuery(con, "SELECT * FROM users WHERE id = ?", params = list(user$id))
    dbDisconnect(con)
    current_user(as.list(updated[1, ]))
    showNotification("R$ 50,00 adicionados à carteira!", type = "message")
  })
  
  observeEvent(input$btn_save_profile, {
    user <- current_user()
    con <- get_db()
    dbExecute(con, "UPDATE users SET bio = ? WHERE id = ?", params = list(input$edit_bio, user$id))
    updated <- dbGetQuery(con, "SELECT * FROM users WHERE id = ?", params = list(user$id))
    dbDisconnect(con)
    current_user(as.list(updated[1, ]))
    showNotification("Perfil atualizado!", type = "message")
  })
  
  output$admin_stats <- renderUI({
    refresh_trigger()
    con <- get_db()
    on.exit(dbDisconnect(con))
    total_users <- dbGetQuery(con, "SELECT COUNT(*) as n FROM users")$n
    total_fees <- dbGetQuery(con, "SELECT COALESCE(SUM(platform_fee), 0) as total FROM live_tickets")$total
    div(class = "row",
        div(class = "col-md-6", div(class = "card-custom", h5("Total de Usuários"), h2(total_users))),
        div(class = "col-md-6", div(class = "card-custom", h5("Comissões da Plataforma (20%)"), h2(paste0("R$ ", sprintf("%.2f", total_fees)))))
    )
  })
  
  output$admin_users_table <- renderTable({
    refresh_trigger()
    con <- get_db()
    on.exit(dbDisconnect(con))
    dbGetQuery(con, "SELECT id, username, email, role, is_verified, wallet_balance FROM users")
  })
  
  observeEvent(input$btn_verify_user, {
    con <- get_db()
    dbExecute(con, "UPDATE users SET is_verified = 1 WHERE id = ?", params = list(input$verify_user_id))
    dbDisconnect(con)
    refresh_trigger(refresh_trigger() + 1)
    showNotification("Usuário verificado (+18)!", type = "message")
  })
  
  observeEvent(input$btn_del_post, {
    con <- get_db()
    dbExecute(con, "DELETE FROM posts WHERE id = ?", params = list(input$del_post_id))
    dbDisconnect(con)
    refresh_trigger(refresh_trigger() + 1)
    showNotification("Postagem removida pelo administrador.", type = "warning")
  })
}

shinyApp(ui, server)
