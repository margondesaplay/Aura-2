# database.R
library(DBI)
library(RSQLite)
library(sodium)

init_db <- function() {
  con <- dbConnect(RSQLite::SQLite(), "plataforma_adulta.sqlite")
  
  # 1. Tabela de Usuários (Admin e Usuários Comuns/Criadores)
  dbExecute(con, "
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'user',         -- 'admin' ou 'user'
      bio TEXT DEFAULT '',
      avatar_url TEXT DEFAULT 'default_avatar.png',
      is_verified INTEGER DEFAULT 0,    -- 0 = pendente, 1 = verificado (+18 KYC)
      wallet_balance REAL DEFAULT 0.0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  ")
  
  # 2. Tabela de Postagens (Timeline: Fotos, Vídeos, Texto)
  dbExecute(con, "
    CREATE TABLE IF NOT EXISTS posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      content_text TEXT,
      media_path TEXT,
      media_type TEXT,                  -- 'text', 'image', 'video'
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )
  ")
  
  # 3. Tabela de Transmissões ao Vivo (Lives Pay-Per-View)
  dbExecute(con, "
    CREATE TABLE IF NOT EXISTS live_streams (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      creator_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      ticket_price REAL NOT NULL,
      stream_key TEXT UNIQUE NOT NULL,
      hls_url TEXT NOT NULL,
      status TEXT DEFAULT 'live',       -- 'live' ou 'ended'
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(creator_id) REFERENCES users(id)
    )
  ")
  
  # 4. Tabela de Ingressos Comprados (Controle de Acesso à Live)
  dbExecute(con, "
    CREATE TABLE IF NOT EXISTS live_tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      live_id INTEGER NOT NULL,
      buyer_id INTEGER NOT NULL,
      amount_paid REAL NOT NULL,
      platform_fee REAL NOT NULL,
      creator_earnings REAL NOT NULL,
      purchased_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(live_id, buyer_id),
      FOREIGN KEY(live_id) REFERENCES live_streams(id),
      FOREIGN KEY(buyer_id) REFERENCES users(id)
    )
  ")
  
  # 5. Tabela de Transações Financeiras (Auditoria)
  dbExecute(con, "
    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      type TEXT NOT NULL,               -- 'deposit', 'ticket_purchase', 'payout'
      amount REAL NOT NULL,
      status TEXT DEFAULT 'completed',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  ")
  
  # Criar conta Administrador padrão se não existir (Senha: admin123)
  admin_exists <- dbGetQuery(con, "SELECT id FROM users WHERE role = 'admin'")
  if (nrow(admin_exists) == 0) {
    hash_admin <- sodium::password_store("admin123")
    dbExecute(con, "
      INSERT INTO users (username, email, password_hash, role, bio, is_verified, wallet_balance)
      VALUES ('admin_master', 'admin@plataforma.com', ?, 'admin', 'Administrador do Sistema', 1, 1000.0)
    ", params = list(hash_admin))
  }
  
  dbDisconnect(con)
}
