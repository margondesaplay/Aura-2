# run_project.R
pacotes <- c("shiny", "bslib", "plumber", "DBI", "RSQLite", "sodium", "jose", "httr", "jsonlite", "callr")
instalar <- pacotes[!(pacotes %in% installed.packages()[, "Package"])]
if (length(instalar) > 0) install.packages(instalar)

# 1. Inicializar Banco de Dados
source("database.R")
init_db()
message(">> Banco de dados inicializado com sucesso.")

# 2. Iniciar API Backend (Plumber) na porta 8000 em background
api_process <- callr::r_bg(function() {
  pr <- plumber::plumb("api_backend.R")
  pr$run(host = "127.0.0.1", port = 8000)
})
Sys.sleep(2)
message(">> API Backend rodando em http://127.0.0.1:8000")

# 3. Iniciar Frontend Shiny na porta 3838
message(">> Iniciando Plataforma Web...")
shiny::runApp("app_frontend.R", host = "127.0.0.1", port = 3838, launch.browser = TRUE)
