# api_backend.R
library(plumber)
library(DBI)
library(RSQLite)
library(sodium)
library(jose)
library(jsonlite)

JWT_SECRET <- charToRaw("CHAVE_SECRETA_ULTRA_SEGURA_MUDE_EM_PRODUCAO_2026")
PLATFORM_FEE_RATE <- 0.20 # 20% de taxa para o administrador

get_db <- function() {
  dbConnect(RSQLite::SQLite(), "plataforma_adulta.sqlite")
}

#* @apiTitle API Rede Social Adulta & Live Pay-Per-View

#* Registrar novo usuário (+18)
#* @post /auth/register
function(username, email, password, age_confirmed = FALSE) {
  if (!as.logical(age_confirmed)) {
    return(list(status = "error", message = "Confirmação de maioridade (+18) obrigatória."))
  }
  
  con <- get_db()
  on.exit(dbDisconnect(con))
  
  hash <- sodium::password_store(password)
  tryCatch({
    dbExecute(con, "
      INSERT INTO users (username, email, password_hash, role, wallet_balance)
      VALUES (?, ?, ?, 'user', 50.0)
    ", params = list(username, email, hash)) # Bônus inicial de R$ 50 para testes
    list(status = "success", message = "Usuário cadastrado com sucesso!")
  }, error = function(e) {
    list(status = "error", message = "Usuário ou e-mail já cadastrado.")
  })
}

#* Login e geração de Token JWT
#* @post /auth/login
function(email, password) {
  con <- get_db()
  on.exit(dbDisconnect(con))
  
  user <- dbGetQuery(con, "SELECT * FROM users WHERE email = ?", params = list(email))
  if (nrow(user) == 0 || !sodium::password_verify(user$password_hash[1], password)) {
    return(list(status = "error", message = "Credenciais inválidas."))
  }
  
  claim <- jwt_claim(
    user_id = user$id[1],
    username = user$username[1],
    role = user$role[1],
    exp = as.numeric(Sys.time()) + 86400
  )
  token <- jwt_encode_hmac(claim, secret = JWT_SECRET)
  
  list(
    status = "success",
    token = token,
    user = list(
      id = user$id[1],
      username = user$username[1],
      role = user$role[1],
      wallet_balance = user$wallet_balance[1]
    )
  )
}

#* Comprar ingresso para assistir Live Paga (Split automático)
#* @post /lives/buy_ticket
function(buyer_id, live_id) {
  con <- get_db()
  on.exit(dbDisconnect(con))
  
  buyer_id <- as.integer(buyer_id)
  live_id <- as.integer(live_id)
  
  # Verificar se já comprou
  existing <- dbGetQuery(con, "SELECT id FROM live_tickets WHERE live_id = ? AND buyer_id = ?", 
                         params = list(live_id, buyer_id))
  if (nrow(existing) > 0) {
    return(list(status = "success", message = "Acesso já liberado."))
  }
  
  live <- dbGetQuery(con, "SELECT * FROM live_streams WHERE id = ?", params = list(live_id))
  buyer <- dbGetQuery(con, "SELECT * FROM users WHERE id = ?", params = list(buyer_id))
  
  if (nrow(live) == 0 || nrow(buyer) == 0) {
    return(list(status = "error", message = "Live ou usuário não encontrado."))
  }
  
  price <- live$ticket_price[1]
  if (buyer$wallet_balance[1] < price) {
    return(list(status = "error", message = "Saldo insuficiente na carteira."))
  }
  
  # Cálculo do Split Financeiro
  fee <- round(price * PLATFORM_FEE_RATE, 2)
  creator_net <- round(price - fee, 2)
  
  dbBegin(con)
  tryCatch({
    # 1. Debita do comprador
    dbExecute(con, "UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?", 
              params = list(price, buyer_id))
    # 2. Credita ao criador da live
    dbExecute(con, "UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?", 
              params = list(creator_net, live$creator_id[1]))
    # 3. Credita comissão ao Admin (ID 1)
    dbExecute(con, "UPDATE users SET wallet_balance = wallet_balance + ? WHERE role = 'admin'", 
              params = list(fee))
    # 4. Registra o ingresso
    dbExecute(con, "
      INSERT INTO live_tickets (live_id, buyer_id, amount_paid, platform_fee, creator_earnings)
      VALUES (?, ?, ?, ?, ?)
    ", params = list(live_id, buyer_id, price, fee, creator_net))
    # 5. Registra transação
    dbExecute(con, "
      INSERT INTO transactions (user_id, type, amount) VALUES (?, 'ticket_purchase', ?)
    ", params = list(buyer_id, -price))
    
    dbCommit(con)
    list(status = "success", message = "Ingresso pago! Transmissão liberada.")
  }, error = function(e) {
    dbRollback(con)
    list(status = "error", message = paste("Erro na transação:", e$message))
  })
}

#* Validar acesso ao stream de vídeo e gerar Token temporário de reprodução
#* @get /lives/stream_access
function(user_id, live_id) {
  con <- get_db()
  on.exit(dbDisconnect(con))
  
  live <- dbGetQuery(con, "SELECT * FROM live_streams WHERE id = ?", params = list(as.integer(live_id)))
  if (nrow(live) == 0) return(list(authorized = FALSE))
  
  # Criador da live ou Admin têm acesso livre
  user <- dbGetQuery(con, "SELECT role FROM users WHERE id = ?", params = list(as.integer(user_id)))
  is_owner <- (live$creator_id[1] == as.integer(user_id))
  is_admin <- (nrow(user) > 0 && user$role[1] == "admin")
  
  ticket <- dbGetQuery(con, "SELECT id FROM live_tickets WHERE live_id = ? AND buyer_id = ?", 
                       params = list(as.integer(live_id), as.integer(user_id)))
  
  if (is_owner || is_admin || nrow(ticket) > 0) {
    stream_token <- jwt_encode_hmac(
      jwt_claim(live_id = live_id, user_id = user_id, exp = as.numeric(Sys.time()) + 3600),
      secret = JWT_SECRET
    )
    return(list(
      authorized = TRUE,
      hls_url = live$hls_url[1],
      stream_token = stream_token
    ))
  } else {
    return(list(authorized = FALSE, price = live$ticket_price[1]))
  }
}
