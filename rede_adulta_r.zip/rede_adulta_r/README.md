# Rede Social Adulta & Live Pay-Per-View (em R)

## Estrutura de Arquivos
- `database.R`: Criação do banco de dados SQLite (`users`, `posts`, `live_streams`, `live_tickets`, `transactions`) e criação do Administrador padrão.
- `api_backend.R`: API REST em `plumber` com autenticação JWT, split financeiro (20% plataforma / 80% criador) e validação de ingressos para lives.
- `app_frontend.R`: Interface web em `shiny` + `bslib` com bloqueio `+18` (Age Gate), Timeline (texto/foto/vídeo), Lives pagas com marca d'água anti-pirataria, Edição de Perfil e Painel Administrador.
- `run_project.R`: Script mestre que instala dependências, inicializa o banco, sobe a API e abre a aplicação.

## Como Executar
1. Extraia o ZIP.
2. Abra o R ou RStudio na pasta `rede_adulta_r`.
3. Execute:
   ```r
   source("run_project.R")
   ```

## Credenciais do Administrador Padrão
- **E-mail:** `admin@plataforma.com`
- **Senha:** `admin123`
